# myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45", "True", "1.02"]

# myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45", ["Parjo", 3, 5]
                    # , {"Key": 3, "Auto": 2}]

myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]

for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
#     print(f"{item} is of the data type {type(item)}")

# print(f"{myMixedTypeList[0]} is of the data type {type(myMixedTypeList[0])}")
# print(f"{myMixedTypeList[1]} is of the data type {type(myMixedTypeList[1])}")
# print(f"{myMixedTypeList[2]} is of the data type {type(myMixedTypeList[2])}")
# print(f"{myMixedTypeList[3]} is of the data type {type(myMixedTypeList[3])}")
# print(f"{myMixedTypeList[4]} is of the data type {type(myMixedTypeList[4])}")
# print(f"{myMixedTypeList[5]} is of the data type {type(myMixedTypeList[5])}")
# print(f"{myMixedTypeList[6]} is of the data type {type(myMixedTypeList[6])}")
# print(f"{myMixedTypeList[7]} is of the data type {type(myMixedTypeList[7])}")




